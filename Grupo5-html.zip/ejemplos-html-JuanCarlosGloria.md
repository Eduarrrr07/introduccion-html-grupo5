<##ejemplo de imagenes html
<img src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.apinem.com%2Fimagenes-html%2F&psig=AOvVaw3kVOWSlHGpom1comaVnH0G&ust=1759623961977000&source=images&cd=vfe&opi=89978449&ved=0CBUQjRxqFwoTCOjGuJukiZADFQAAAAAdAAAAABAE">
<a bref="https://developer.mozilla.org/es/docs/Learn_web_development/Core/Structuring_content/HTML_images">Ir a Google</a>


<##ejemplos de html completo
<html>
  <head>
    <title>Página de ejemplo</title>
  </head>
  <body>
    <h1>Hola Mundo</h1>
    <p>Esta es una página para el laboratorio de Software V</p>
  </body>
</html>



