### Lista no ordenada
<ul>
<li>Elemento 1</li>
<li>Elemento 2</li>
<li>Elemento 3</li>
</ul>



### Lista ordenada
<ol>
  <li>Primer paso</li>
  <li>Segundo paso</li>
  <li>Tercer paso</li>
</ol>



### Tabla
<table border="1">
  <tr>
    <th>Nombre</th>
    <th>Edad</th>
    <th>País</th>
  </tr>
  <tr>
    <td>Valerie</td>
    <td>18</td>
    <td>Panamá</td>
  </tr>
  <tr>
    <td>Carlos</td>
    <td>22</td>
    <td>México</td>
  </tr>
</table>
